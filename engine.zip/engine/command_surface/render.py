from __future__ import annotations

from pathlib import Path
import html
import json
import os

from engine.command_surface.config import (
    ViewerDefaults,
    resolve_default_layer,
    resolve_default_padus_mode,
)
from engine.command_surface.payloads import (
    build_cluster_markup,
    build_invalidators,
    build_layer_buttons,
    build_payload,
    build_ranked_rows,
)
from engine.command_surface.template import HTML_TEMPLATE
from engine.terrain_truth.contract import TerrainTruthContract


def _coverage_sentence(ratio: float) -> str:
    pct = round(max(0.0, min(1.0, ratio)) * 100)
    if pct >= 55:
        tone = "Strong legal spread across this terrain window."
    elif pct >= 25:
        tone = "Useful legal coverage is present, but edge management matters."
    elif pct > 0:
        tone = "Legal land is limited here, so entry and exit discipline matters."
    else:
        tone = "No verified PAD-US legal surface is inside this box."
    return f"{pct}% PAD-US legal coverage in this box. {tone}"


def _terrain_sentence(summary: dict) -> str:
    strength = str(summary.get("terrain_strength") or "unknown").replace("_", " ").title()
    trust = str(summary.get("surface_trust") or "unverified").replace("_", " ").title()
    return f"Terrain read: {strength}. Viewer trust: {trust}."


def _wind_sentence(decision_summary: dict) -> str:
    current = str(decision_summary.get("current_wind") or "Not set")
    preferred = str(decision_summary.get("preferred_wind") or "Unknown")
    wind_fit = str(decision_summary.get("wind_fit") or "unknown").replace("_", " ").title()
    return f"Current wind {current}. Preferred wind {preferred}. Wind fit reads {wind_fit}."


def _vegetation_sentence(contract: TerrainTruthContract) -> str:
    veg = contract.vegetation
    classification = str(veg.classification or "unknown").title()
    provider = str(veg.provider or "unknown")

    if provider == "nlcd_annual":
        source = "NLCD (real data)"
        confidence = "High"
    elif provider == "terrain_heuristic":
        source = "Terrain-based fallback"
        confidence = "Medium"
    else:
        source = "Unavailable / failed"
        confidence = "Low"

    note = ""
    if veg.notes:
        note = veg.notes[0]
        note = note.replace("Heuristic fallback:", "").strip()

    return f"{classification} cover · Source: {source} · Confidence: {confidence}. {note}"


def _vegetation_signal(contract: TerrainTruthContract) -> tuple[str, str, str]:
    veg = contract.vegetation
    classification = str(veg.classification or "unknown").lower()

    if classification == "forest":
        return (
            "Strong Forest Concealment",
            "Boosting bedding reliability",
            "Reduced",
        )
    if classification == "shrub":
        return (
            "Moderate Concealment",
            "Supporting movement and partial bedding",
            "Moderate",
        )
    if classification == "open":
        return (
            "Low Cover / Exposure Risk",
            "Reducing bedding reliability",
            "High",
        )
    if classification == "water":
        return (
            "Non-viable Cover",
            "Blocking bedding and most movement",
            "Extreme",
        )

    return (
        "Unknown Cover",
        "Limited vegetation signal",
        "Unknown",
    )



DEFAULT_STRIPE_PAYMENT_LINK = "https://buy.stripe.com/8x2aEWb6f5qR7Td1mweEo00"


def _checkout_url() -> str:
    return "/checkout"


def _monetization_right_rail_markup() -> str:
    return (
        '<div class="intel-row provider-ok">'
        '<strong>Monahinga™ — Terrain Intelligence</strong>'
        '<span>This run produced a usable terrain read for field planning.</span>'
        '</div>'

        '<div class="intel-row provider-ok">'
        '<strong>Save this scouting run</strong>'
        '<span>Use Download Summary for the written report, copy coordinates for your notes, and use How to Save View for terrain images.</span>'
        '</div>'

        '<div class="intel-row provider-ok">'
        '<strong>Plan more than one move</strong>'
        '<span>Compare your primary sit against backup access, wind shifts, terrain funnels, and pressure changes before stepping into the field.</span>'
        '</div>'

        '<div class="intel-row provider-ok">'
        '<strong>Verify before acting</strong>'
        '<span>Monahinga™ supports scouting decisions, but you must confirm land access, seasons, tags, weapon rules, weather, and safety conditions.</span>'
        '</div>'

        '<div class="intel-row provider-ok">'
        '<strong>Field-ready workflow</strong>'
        '<span>Rotate the terrain, save the view you want, download the summary, and carry both into your scouting notes.</span>'
        '</div>'
    )

def _wildlife_atmosphere_markup(operator_context: dict) -> str:
    wildlife = (operator_context or {}).get("wildlife_atmosphere") or {}
    species = wildlife.get("species") or []
    if not isinstance(species, list) or not species:
        return ""

    def esc(value: object) -> str:
        return html.escape(str(value or ""))

    cards: list[str] = []
    for idx, item in enumerate(species[:3], start=1):
        if not isinstance(item, dict):
            continue
        name = esc(item.get("name"))
        role = esc(item.get("role"))
        movement = esc(item.get("movement_read"))
        methods = item.get("methods") or []
        method_text = " · ".join(esc(method) for method in methods[:3])
        cards.append(
            '<div class="wildlife-card">'
            f'<div class="wildlife-rank">0{idx}</div>'
            f'<div class="wildlife-name">{name}</div>'
            f'<div class="wildlife-role">{role}</div>'
            f'<div class="wildlife-motion">{movement}</div>'
            f'<div class="wildlife-methods">{method_text}</div>'
            '</div>'
        )

    if not cards:
        return ""

    label = esc(wildlife.get("label") or "Wildlife atmosphere")
    mood = esc(wildlife.get("mood") or "Region-driven visual context")
    legal_note = esc(wildlife.get("legal_note") or "Verify state regulations before hunting.")
    return (
        '<div class="wildlife-atmo-layer" aria-hidden="false">'
        '<div class="wildlife-atmo-panel wildlife-atmo-left">'
        '<div class="wildlife-kicker">Wildlife atmosphere</div>'
        f'<div class="wildlife-region">{label}</div>'
        f'<div class="wildlife-mood">{mood}</div>'
        '</div>'
        '<div class="wildlife-atmo-panel wildlife-atmo-right">'
        + "".join(cards) +
        f'<div class="wildlife-legal-note">{legal_note}</div>'
        '</div>'
        '</div>'
    )


def _provider_status_class(status: str) -> str:
    normalized = str(status or "").strip().lower()
    if normalized in {"ok", "healthy", "available", "cache", "cached"}:
        return "provider-ok"
    if normalized in {"empty", "partial", "limited", "unknown", "degraded"}:
        return "provider-empty"
    if normalized in {"failed", "error", "unavailable", "none"}:
        return "provider-failed"
    return "provider-empty"


def _provider_status_markup(notes: list[str]) -> str:
    terrain = "unknown"
    legal = "unknown"
    vegetation = "unknown"
    messages: list[str] = []

    for note in notes:
        if note.startswith("Provider status:"):
            parts = note.replace("Provider status:", "").split(",")
            for part in parts:
                if "terrain=" in part:
                    terrain = part.split("=", 1)[1].strip().lower()
                if "legal=" in part:
                    legal = part.split("=", 1)[1].strip().lower()
                if "vegetation=" in part:
                    vegetation = part.split("=", 1)[1].strip().lower()
        elif "provider failed" in note.lower() or "no accessible features" in note.lower() or "nlcd" in note.lower():
            messages.append(note)

    rows = [
        f'<div class="intel-row {_provider_status_class(terrain)}"><strong>Terrain provider</strong><span>{html.escape(terrain.title())}</span></div>',
        f'<div class="intel-row {_provider_status_class(legal)}"><strong>Legal provider</strong><span>{html.escape(legal.title())}</span></div>',
        f'<div class="intel-row {_provider_status_class(vegetation)}"><strong>Vegetation provider</strong><span>{html.escape(vegetation.title())}</span></div>',
    ]

    for msg in messages:
        rows.append(
            f'<div class="intel-row provider-failed"><strong>Provider note</strong><span>{html.escape(msg)}</span></div>'
        )

    return "".join(rows)


def _format_coords(lat: float, lon: float) -> str:
    return f"Lat {lat:.6f} · Lon {lon:.6f}"


def _coordinate_rows(primary, alternates: list) -> str:
    rows = [
        f'<div class="intel-row"><strong>Primary sit coordinates</strong><span>{html.escape(_format_coords(primary.lat, primary.lon))} · {int(round(primary.elevation_m))} m</span></div>'
    ]
    for site in alternates[:2]:
        rows.append(
            f'<div class="intel-row"><strong>{html.escape(site.title)} coordinates</strong><span>{html.escape(_format_coords(site.lat, site.lon))} · {int(round(site.elevation_m))} m</span></div>'
        )
    return "".join(rows)


def _box_status(decision_summary: dict, coverage_ratio: float) -> tuple[str, str, str]:
    legal_state = str(decision_summary.get("legal_state") or "none")
    if legal_state == "strong":
        return (
            "Strong verified legal hunting land",
            "Most of the selected box is covered by verified PAD-US legal hunting land.",
            "strong",
        )
    if legal_state == "partial" or coverage_ratio > 0:
        return (
            "Partial verified legal hunting land",
            "Only part of the selected box carries verified PAD-US legal hunting land, so edge discipline matters.",
            "partial",
        )
    return (
        "No verified legal hunting land",
        "No verified PAD-US legal land was found inside the selected box.",
        "none",
    )


def render_command_surface(run_root: Path, contract: TerrainTruthContract) -> Path:
    terrain_truth_root = run_root / "terrain_truth"
    derivative_dir = terrain_truth_root / "terrain_derivatives"
    summary = json.loads((derivative_dir / "terrain_summary.json").read_text(encoding="utf-8"))

    layer_files = {
        "terrain": derivative_dir / "terrain_render.png",
        "hillshade": derivative_dir / "hillshade.png",
        "slope": derivative_dir / "slope.png",
        "relief": derivative_dir / "local_relief.png",
    }
    available_layers = {
        key: f"../{str(path.relative_to(run_root)).replace(chr(92), '/')}"
        for key, path in layer_files.items()
        if path.exists()
    }

    viewer_defaults = ViewerDefaults(default_layer=resolve_default_layer(available_layers))
    payload = build_payload(run_root, contract, available_layers, summary, viewer_defaults)

    legal_summary = payload.get("summary") or {}
    resolved_padus_mode = resolve_default_padus_mode(
        float(legal_summary.get("legal_coverage_ratio") or 0.0),
        bool(legal_summary.get("legal_cropped_to_bbox")),
    )
    viewer_defaults = ViewerDefaults(
        default_layer=viewer_defaults.default_layer,
        default_padus_mode=resolved_padus_mode,
    )
    payload["defaultPadusMode"] = resolved_padus_mode
    payload_json = json.dumps(payload)

    decision_summary = contract.decision.summary or {}
    operator_context = contract.operator_context or {}
    primary = contract.decision.primary
    sites = [contract.decision.primary] + contract.decision.alternates + contract.decision.near_misses
    min_lon, min_lat, max_lon, max_lat = contract.bbox

    legal_badge = (
        "Legal fill clipped to terrain bbox"
        if legal_summary.get("legal_cropped_to_bbox")
        else "Legal fill contained inside terrain bbox"
    )

    primary_elevation_text = (
        f"{primary.title} sits at about {int(round(primary.elevation_m))} meters "
        f"and remains the lead setup."
    )
    box_status_title, box_status_body, box_status_tone = _box_status(
        decision_summary,
        float(legal_summary.get("legal_coverage_ratio") or 0.0),
    )
    pin_mode_text = (
        "Strong verified legal hunting land. Primary and alternate pins are being drawn only from verified legal land inside your selected box."
        if str(decision_summary.get("analysis_mode")) == "legal_hunt"
        else "No verified legal hunting land. Terrain-only review mode is active, so pins are exploration guidance rather than verified legal hunting spots."
    )

    provider_markup = _provider_status_markup(contract.notes or [])
    cover_read, veg_impact, exposure = _vegetation_signal(contract)
    vegetation_signal_markup = "".join(
        [
            f'<div class="intel-row"><strong>Cover</strong><span>{html.escape(cover_read)}</span></div>',
            f'<div class="intel-row"><strong>Impact</strong><span>{html.escape(veg_impact)}</span></div>',
            f'<div class="intel-row"><strong>Exposure</strong><span>{html.escape(exposure)}</span></div>',
        ]
    )

    wildlife_atmosphere_markup = _wildlife_atmosphere_markup(operator_context)

    hunting_read_markup = "".join(
        [
            _monetization_right_rail_markup(),
            f'<div class="intel-row"><strong>Analysis mode</strong><span>{html.escape((decision_summary.get("selected_species") or "General Terrain Read").replace("_"," ").title())}</span></div>',
            f'<div class="intel-row"><strong>Species read</strong><span>{html.escape((decision_summary.get("species_profile") or {}).get("positive_hook",""))}</span></div>',
            f'<div class="intel-row"><strong>Cover read</strong><span>{html.escape(cover_read)}</span></div>',
            f'<div class="intel-row"><strong>Vegetation impact</strong><span>{html.escape(veg_impact)}</span></div>',
            f'<div class="intel-row"><strong>Exposure risk</strong><span>{html.escape(exposure)}</span></div>',
            f'<div class="intel-row"><strong>Legal coverage inside box</strong><span>{html.escape(_coverage_sentence(float(legal_summary.get("legal_coverage_ratio") or 0.0)))}</span></div>',
            f'<div class="intel-row"><strong>Legal state</strong><span>{html.escape(pin_mode_text)}</span></div>',
            f'<div class="intel-row"><strong>Terrain pull</strong><span>{html.escape(_terrain_sentence(legal_summary))}</span></div>',
            f'<div class="intel-row"><strong>Vegetation read</strong><span>{html.escape(_vegetation_sentence(contract))}</span></div>',
            f'<div class="intel-row"><strong>Cover layer</strong><span>{html.escape("Toggle Cover to separate dense concealment, moderate cover, and open ground in the 3D viewer. Selected sit glow marks the current read zone.")}</span></div>',
            provider_markup,
            f'<div class="intel-row"><strong>Live wind near primary sit</strong><span id="liveWindSummary">Loading live wind…</span><small id="liveWindMeta" class="micro-copy">Manual fallback remains available if live weather does not load.</small></div>',
            f'<div class="intel-row"><strong>Wind read</strong><span>{html.escape(_wind_sentence(decision_summary))}</span></div>',
            f'<div class="intel-row"><strong>Primary sit elevation</strong><span>{html.escape(primary_elevation_text)}</span></div>',
            _coordinate_rows(primary, contract.decision.alternates),
        ]
    )

    html_doc = HTML_TEMPLATE.substitute(
        provider=html.escape(contract.terrain.provider),
        legal_provider=html.escape(contract.legal_surface.provider),
        min_lon=f"{min_lon:.4f}",
        min_lat=f"{min_lat:.4f}",
        max_lon=f"{max_lon:.4f}",
        max_lat=f"{max_lat:.4f}",
        mesh_w=html.escape(str(summary.get("width"))),
        mesh_h=html.escape(str(summary.get("height"))),
        default_layer_label=html.escape(viewer_defaults.default_layer.title()),
        default_padus_label=html.escape(viewer_defaults.default_padus_mode.title()),
        legal_badge=html.escape(legal_badge),
        mode=html.escape(str(operator_context.get("mode") or "hunter").title()),
        current_wind=html.escape(str(decision_summary.get("current_wind") or "Not set")),
        preferred_wind=html.escape(str(decision_summary.get("preferred_wind") or "Unknown")),
        readiness=html.escape(str(decision_summary.get("readiness") or "Conditional")),
        layer_buttons=build_layer_buttons(available_layers, viewer_defaults.default_layer),
        selected_box_status_markup=f'<div class="block status-block tone-{box_status_tone}"><h3>Selected Box Status</h3><div class="note"><strong>{html.escape(box_status_title)}</strong><br>{html.escape(box_status_body)}</div></div>',
        operator_notes=html.escape(
            str(operator_context.get("notes") or "No operator notes supplied for this run.")
        ),
        best_time_label=html.escape(str(decision_summary.get("best_time_label") or "Prime window")),
        best_time_window=html.escape(str(decision_summary.get("best_time_window") or "Field-check timing.")),
        primary_title=html.escape(primary.title),
        confidence_label=html.escape(str(decision_summary.get("confidence_label") or "Medium")),
        confidence=html.escape(str(decision_summary.get("confidence") or "")),
        primary_reason=html.escape(
            (
                f"{(decision_summary.get('species_profile') or {}).get('positive_hook', '')} {primary.reasoning}"
                if (decision_summary.get('species_profile') or {}).get('positive_hook', '')
                else primary.reasoning
            )
        ),
        primary_tags=html.escape(json.dumps(list(decision_summary.get("trust_tags") or []))),
        primary_score=html.escape(str(primary.score)),
        cluster_markup=build_cluster_markup(decision_summary),
        hunting_read_markup=hunting_read_markup,
        vegetation_signal_markup=vegetation_signal_markup,
        wildlife_atmosphere_markup=wildlife_atmosphere_markup,
        invalidators=build_invalidators(decision_summary),
        ranked_rows=build_ranked_rows(sites),
        payload_json=payload_json,
    )

    output_dir = run_root / "command_surface"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / "index.html"
    output_path.write_text(html_doc, encoding="utf-8")
    return output_path
